export enum MessageExceptionsEnum {
  MessageNotFound = 'MESSAGE_NOT_FOUND',
  NotMessageAuthor = 'NOT_MESSAGE_AUTHOR',
}
