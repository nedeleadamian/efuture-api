export enum UserExceptionsEnum {
  UserNotFound = 'USER_NOT_FOUND',
  RolerNotFound = 'ROLE_NOT_FOUND',
}