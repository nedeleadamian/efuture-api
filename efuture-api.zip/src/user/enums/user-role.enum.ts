export enum UserRole {
  Admin = 'admin',
  User = 'user',
}